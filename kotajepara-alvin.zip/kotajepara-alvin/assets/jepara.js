console.log("Selamat Anda berhasil menggunakan JavaScript pada Website")
alert("Selamat Datang Di Web Jepara Kota By Alvin ");

